#!/bin/sh
/usr/bin/python3 hw6_semantics.py $@
