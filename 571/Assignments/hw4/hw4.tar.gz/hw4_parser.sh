python3 hw4_parser.py $@
