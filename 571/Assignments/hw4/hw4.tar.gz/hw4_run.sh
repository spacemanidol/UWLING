#PCFG Generation
./hw4_topcfg.sh $1 $2

#Basic Parse
./hw4_parser.sh $2 $3 $4

#Improved Parse
./hw4_improved_parser.sh $2 $3 $6

#Evaluation
/dropbox/18-19/571/hw4/tools/evalb -p /dropbox/18-19/571/hw4/tools/COLLINS.prm /dropbox/18-19/571/hw4/data/parses.gold  $4 > $7
/dropbox/18-19/571/hw4/tools/evalb -p /dropbox/18-19/571/hw4/tools/COLLINS.prm  /dropbox/18-19/571/hw4/data/parses.gold $6 > $8
