#!/bin/sh
python main.py /opt/dropbox/18-19/473/project5/language-models /opt/dropbox/18-19/473/project5/extra-test.txt 1
