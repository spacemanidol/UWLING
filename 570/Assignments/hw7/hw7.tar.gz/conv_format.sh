#!/bin/sh
python3 conv_format.py $@