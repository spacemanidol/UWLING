#!/bin/sh
python3 viterbi.py $@