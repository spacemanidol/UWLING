Daniel Campos
Ling 571 HW8
11/21/2018
1. Results (Examples)
(tie, jacket, 6.741793495904226) (tie, suit, 6.741793495904226)
necktie.n.01
(suit, jacket, 6.741793495904226) (suit, tie, 6.741793495904226)
suit.n.01
(head, body, 5.482209930993152) (head, hand, 6.7329196557411395) (head, eye, 4.598801705037286) (head, voice, 4.43543481913528)
head.n.11
car,automobile:7.279746767224995
journey,voyage:7.416539807812446
boy,lad:8.420284226794253
coast,shore:8.883231007190307
2. Approach & Work
My approach to this problem was to first to build out the general shell of the program using the built in methods. After I had that implemented and was producing ballpark output to the gold file I started building out my specific implementations. 
3. Problems
    None that I know of. 
4. Insights
A little independent of the assignment I learned all about hyponyms and hypernyms and I used them to try to play around with different correlation. I think there is some interesting research to be done around paraphrasing similarity using an expanded method. 