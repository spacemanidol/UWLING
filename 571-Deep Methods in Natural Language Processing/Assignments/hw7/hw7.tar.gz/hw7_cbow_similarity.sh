#!/bin/sh
export PYTHONHASHSEED=1
python3 hw7_cbow_similarity.py $@