#!/bin/sh
export PYTHONHASHSEED=1
python3 hw7_dist_similarity.py $@