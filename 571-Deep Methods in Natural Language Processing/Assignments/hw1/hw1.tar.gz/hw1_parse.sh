#!/bin/sh
python3 main.py $1 $2 $3
